# Playwright Automation

Always read:
- docs/study/modules/<module>
- docs/test-plan/<module>

Generate only approved tests.

Reuse:
- Page Objects
- Fixtures
- Helpers
- Services
- Types
- Generators

Rules:
- Independent tests
- Parallel safe
- No duplicated locators
- No hardcoded waits
- Assertions derived only from approved test plan.


---

# Screenshot Generation Rules

Generate screenshot checkpoints based on the approved test plan.

Always capture:
- Initial page
- Before major action
- After major action
- Validation message
- Popup before confirmation
- Popup after confirmation
- Success message
- Final page
- Unexpected failure

Use reusable screenshot helper methods instead of inline page.screenshot() where possible.

The generated screenshot names shall follow the naming convention defined in the test plan.
