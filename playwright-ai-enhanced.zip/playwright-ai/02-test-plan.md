# Module Test Plan

Generate one module at a time.

Output:

docs/test-plan/<module>/

Files:
- functional.md
- validation.md
- e2e.md

---

# Functional Test Plan

Functional tests include BOTH Happy and Unhappy scenarios.

## Happy Flow
- Navigation
- CRUD
- Search
- Filter
- Sort
- Pagination
- Business Workflow
- Authorization

## Unhappy Flow
- Invalid Workflow
- Invalid Navigation
- Unauthorized Access
- Session Timeout
- Browser Back
- Refresh
- Duplicate Submission
- Concurrent Update
- No Search Result
- Invalid State Transition

Each test case shall contain:
- Test ID
- Priority
- Preconditions
- Test Data
- Steps
- Expected UI
- Expected Database
- Expected Audit Log
- Cleanup

---

# Validation Test Plan

Before creating tests determine:

- Client or Server validation
- Blur / Submit / Save validation
- Popup or Inline validation
- One-by-one validation or All-at-once validation

## Validation Design Rules

If validation is one-by-one:
- Generate one independent test per validation message.

If validation is all-at-once:
- Generate one test validating every message.

Always verify:
- Exact message text
- Capitalisation
- Punctuation
- Placeholder values
- Message location
- Message order
- Focus behaviour
- Error disappears after correction

## Popup Validation

Verify:
- Popup displayed
- Title
- Message
- Icon
- Confirm button
- Cancel button
- Close button
- ESC behaviour
- ENTER behaviour
- Background disabled
- Dynamic placeholders

## Success Validation

Verify:
- Success dialog/toast
- Exact message
- Redirect
- Database update
- Audit Log

---

# End-to-End Test Plan

Generate complete business flows.

Verify:
- Cross-module behaviour
- Status transition
- Stored Procedures
- Database persistence
- Notifications
- Downstream modules

---

# Test Data

Specify:
- Static Data
- Dynamic Data
- Existing Dataset
- Generator Required
- Cleanup Required

Do not hardcode business values.
Reuse existing datasets whenever possible.


---

# Screenshot & Execution Evidence Plan

For every generated test case, identify the screenshots required.

## Screenshot Checkpoints

Capture screenshots at the following checkpoints when applicable:

### Initial State
- Before user interaction.
- Landing page.
- Existing record.
- Empty form.

### Before Action
- Before Save
- Before Submit
- Before Delete
- Before Approve
- Before Confirm

### After Action
- After Save
- After Submit
- After Delete
- After Approve
- After Navigation

### Validation
Capture whenever validation is triggered.

Analyse whether validation occurs:
- One field at a time
- Multiple fields together
- Inline
- Popup
- Client-side
- Server-side

Capture:
- Entire page
- Field in error
- Validation message
- Popup (if any)

### Popup Validation

Whenever a popup appears, capture:
- Popup title
- Popup message
- Popup icon
- Buttons
- Background page
- Before clicking a popup button
- After popup closes

Validate:
- Exact message
- Capitalisation
- Dynamic placeholders
- Button labels
- Button order

### Success Message
Capture:
- Toast/Dialog
- Redirect result
- Updated page

### Failure
Capture unexpected failures before cleanup.

## Screenshot Naming

<Module>_<TestId>_<Step>

Example:
Customer_TC001_BeforeSave
Customer_TC001_ValidationPopup
Customer_TC001_AfterSave

## Test Plan Template

Every test shall include:

| Step | Action | Expected Result | Screenshot Required | Screenshot Name |
|------|--------|-----------------|---------------------|-----------------|
