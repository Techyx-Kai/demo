# Framework Standard

- Module-first organisation
- Page Object Model
- Shared Fixtures
- Shared Helpers
- Shared Services
- Shared Generators
- Shared Constants
- Type-safe implementation
- Centralised reporting
- Consistent screenshot strategy
- Tagging strategy


## Screenshot Standard

Provide a common screenshot helper shared across all modules.

Support:
- Initial
- Before Action
- After Action
- Validation
- Popup
- Success
- Failure
- Final
