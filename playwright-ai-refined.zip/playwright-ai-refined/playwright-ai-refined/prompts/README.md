# Prompt Execution Order

1. Generate Knowledge Base.
2. Review generated module documentation.
3. Generate Functional, Validation and End-to-End Test Plans.
4. Review and approve.
5. Generate Playwright automation.
6. Update knowledge base and coverage.

Always work module-by-module.
