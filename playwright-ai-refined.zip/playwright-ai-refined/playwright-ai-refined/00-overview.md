# Playwright AI Framework

## Goal
Build a maintainable, module-first Playwright framework.

Workflow:
```
Source Code
    ↓
Knowledge Base
    ↓
Module Test Plan
    ↓
Review & Approval
    ↓
Playwright Test Generation
    ↓
Coverage Update
    ↓
Knowledge Base Update
```

## Principles
- Module-by-module development.
- Knowledge Base is the single source of truth.
- Never generate automation before an approved test plan.
- Documentation, test plans and automation must remain synchronized.

## Workspace
- HCCSS/hccss-app-web-playwright
- HCCSS/hccss-credit-control-rad
- HCCSS/hccss-db-db_ebiz-iaas
