# Knowledge Base

## Objective
Study the following repositories:

- hccss-credit-control-rad
- hccss-db-db_ebiz-iaas
- hccss-app-web-playwright

Analyse:
- Spring MVC Controllers
- JSP
- JavaScript
- Services
- SQL Tables
- Stored Procedures
- Business Rules
- Existing Playwright

Output:

docs/study/modules/<module>/

Each module contains:
- overview.md
- navigation.md
- business-rules.md
- controllers.md
- jsp.md
- database.md
- validation.md
- datasets.md
- coverage.md

Document:
Purpose, Navigation, UI Components, Controllers, Services,
Stored Procedures, Tables, Success/Error Messages,
Dependencies, Upstream/Downstream Modules,
Existing Coverage and Missing Coverage.
