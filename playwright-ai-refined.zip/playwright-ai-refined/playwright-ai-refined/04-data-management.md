# Data Management

Module-first structure:

shared/
  constants/
  generators/
  environments/

<module>/
  data/
    default.data.ts
    add.data.ts
    update.data.ts
    validation.data.ts
    overrides/
      sit.ts
      uat.ts

Hierarchy:
Shared Constants
→ Environment
→ Module Defaults
→ Scenario Overrides
→ Runtime Generated Values

AI Rules:
1. Search existing constants.
2. Search existing generators.
3. Search existing module data.
4. Reuse before creating.
5. Never hardcode business values.
