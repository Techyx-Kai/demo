# Playwright Automation

Always read:
- docs/study/modules/<module>
- docs/test-plan/<module>

Generate only approved tests.

Reuse:
- Page Objects
- Fixtures
- Helpers
- Services
- Types
- Generators

Rules:
- Independent tests
- Parallel safe
- No duplicated locators
- No hardcoded waits
- Assertions derived only from approved test plan.
