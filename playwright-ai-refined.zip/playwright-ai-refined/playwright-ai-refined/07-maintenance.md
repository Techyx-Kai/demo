# Maintenance

After every completed module:

Update:
- Knowledge Base
- Module Test Plan
- Coverage
- Dataset
- Automation

Never allow documentation, test plans and automation to drift apart.

If business logic changes:
1. Update Knowledge Base.
2. Update Test Plan.
3. Regenerate affected automation.
4. Update Coverage.
