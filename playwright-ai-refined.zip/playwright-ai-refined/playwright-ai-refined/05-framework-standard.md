# Framework Standard

- Module-first organisation
- Page Object Model
- Shared Fixtures
- Shared Helpers
- Shared Services
- Shared Generators
- Shared Constants
- Type-safe implementation
- Centralised reporting
- Consistent screenshot strategy
- Tagging strategy
