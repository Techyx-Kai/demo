# Module Test Plan

Generate one module at a time.

Output:

docs/test-plan/<module>/

Files:
- functional.md
- validation.md
- e2e.md

---

# Functional Test Plan

Functional tests include BOTH Happy and Unhappy scenarios.

## Happy Flow
- Navigation
- CRUD
- Search
- Filter
- Sort
- Pagination
- Business Workflow
- Authorization

## Unhappy Flow
- Invalid Workflow
- Invalid Navigation
- Unauthorized Access
- Session Timeout
- Browser Back
- Refresh
- Duplicate Submission
- Concurrent Update
- No Search Result
- Invalid State Transition

Each test case shall contain:
- Test ID
- Priority
- Preconditions
- Test Data
- Steps
- Expected UI
- Expected Database
- Expected Audit Log
- Cleanup

---

# Validation Test Plan

Before creating tests determine:

- Client or Server validation
- Blur / Submit / Save validation
- Popup or Inline validation
- One-by-one validation or All-at-once validation

## Validation Design Rules

If validation is one-by-one:
- Generate one independent test per validation message.

If validation is all-at-once:
- Generate one test validating every message.

Always verify:
- Exact message text
- Capitalisation
- Punctuation
- Placeholder values
- Message location
- Message order
- Focus behaviour
- Error disappears after correction

## Popup Validation

Verify:
- Popup displayed
- Title
- Message
- Icon
- Confirm button
- Cancel button
- Close button
- ESC behaviour
- ENTER behaviour
- Background disabled
- Dynamic placeholders

## Success Validation

Verify:
- Success dialog/toast
- Exact message
- Redirect
- Database update
- Audit Log

---

# End-to-End Test Plan

Generate complete business flows.

Verify:
- Cross-module behaviour
- Status transition
- Stored Procedures
- Database persistence
- Notifications
- Downstream modules

---

# Test Data

Specify:
- Static Data
- Dynamic Data
- Existing Dataset
- Generator Required
- Cleanup Required

Do not hardcode business values.
Reuse existing datasets whenever possible.
