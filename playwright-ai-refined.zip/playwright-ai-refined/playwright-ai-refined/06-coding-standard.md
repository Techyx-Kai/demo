# Coding Standard

- SOLID
- DRY
- TypeScript strict mode
- Small reusable methods
- No duplicated locators
- No hardcoded waits
- Prefer expect() over waitForTimeout()
- Centralised test data
- Self-cleaning tests
- Consistent naming conventions
