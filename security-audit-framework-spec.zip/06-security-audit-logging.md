# Security Audit Logging

Populate MDC:
- traceId
- contextId
- bizFunc
- messageType
- bizKeys

Generate:
- Enter method()
- Exit method()
- Exit method() - FAILED

Use Jackson for JSON serialization.
