# Business Field Selection

The framework shall discover every available request field but SHALL NOT automatically log every field.

Generate an audit metadata report.

Developers determine which fields are included.

Example:

audit-metadata.yml

CLAIM:
  APPROVE:
    include-fields:
      - claimNo
      - transactionId
      - policyNo

If no configuration exists, only mandatory audit information (userId, clientIp) is logged.
