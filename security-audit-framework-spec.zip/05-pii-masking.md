# PII Masking

Mask values matching configurable patterns.

Default patterns:
- *PolicyNo
- *PolicyNumber
- *Name
- *CustomerName
- *InsuredName
- *PhoneNo
- *MobileNo
- *ContactNumber
- *Email
- *EmailAddress

Mask after field extraction and before serialization.
