# Request Data Extraction

Support:
- application/json
- @RequestBody
- @ModelAttribute
- @RequestParam
- @PathVariable
- Multipart

Use RequestBodyAdvice to capture JSON requests.

Convert request objects into Map<String,Object> using the application's ObjectMapper.

Merge all request sources into a Unified Request Model.

BusinessFieldExtractor operates only on the Unified Request Model.
