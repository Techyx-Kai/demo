# Enterprise Security Audit Logging Framework

## Objective
Design an enterprise-grade reusable Security Audit Logging Framework for Spring Boot 3 and Java 21.

## Scope
- Controller-level auditing
- Automatic metadata discovery
- Support REST and Spring MVC
- Enterprise EFK integration

## Technology
- Java 21
- Spring Boot 3
- Spring MVC
- Jackson
- HandlerInterceptor
- RequestBodyAdvice
- MDC
- SLF4J
