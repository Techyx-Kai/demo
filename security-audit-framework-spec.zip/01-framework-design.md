# Framework Design

## Components
- SecurityAuditInterceptor
- AuditMetadataScanner
- AuditMetadataRegistry
- RequestDataProvider
- BusinessFieldExtractor
- PiiMaskingService
- JsonAuditSerializer
- SecurityAuditLogger

## Startup
1. Scan controllers
2. Discover @SecurityAudit
3. Build metadata registry
4. Generate audit report

## Runtime
Request -> Interceptor -> Unified Request Model -> Field Extraction -> PII Masking -> MDC -> Audit Log
