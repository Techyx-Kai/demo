# Audit Metadata Discovery

The framework shall:

- Scan all @RestController and @Controller beans.
- Discover every @SecurityAudit annotation.
- Discover module and action.
- Discover HTTP method and endpoint.
- Discover request DTOs, @RequestBody, @ModelAttribute, @RequestParam, @PathVariable and multipart requests.
- Build an in-memory AuditMetadataRegistry.

No module/action mappings shall be maintained in application.properties.

Generate a startup report listing:
- Module
- Action
- Endpoint
- Request Type
- Discovered fields
- Potential PII
